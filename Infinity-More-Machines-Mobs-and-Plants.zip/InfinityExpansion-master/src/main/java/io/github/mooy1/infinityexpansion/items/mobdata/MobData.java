package io.github.mooy1.infinityexpansion.items.mobdata;

import lombok.experimental.UtilityClass;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import io.github.mooy1.infinityexpansion.InfinityExpansion;
import io.github.mooy1.infinityexpansion.categories.Groups;
import io.github.mooy1.infinityexpansion.items.materials.Materials;
import io.github.mooy1.infinitylib.core.Environment;
import io.github.mooy1.infinitylib.machines.MachineLore;
import io.github.thebusybiscuit.slimefun4.api.items.SlimefunItem;
import io.github.thebusybiscuit.slimefun4.api.items.SlimefunItemStack;
import io.github.thebusybiscuit.slimefun4.api.recipes.RecipeType;
import io.github.thebusybiscuit.slimefun4.implementation.SlimefunItems;

//Changes made to this page by How.
//Added more contstructors 1/29 1/24 1/28/24 for custom data card items.
//Changes also made 5/24/24. 
//Credit to Original Author(s) Mooy1.
@UtilityClass
public final class MobData {

    private static final int CHAMBER_INTERVAL =
            InfinityExpansion.config().getInt("mob-simulation-options.ticks-per-output", 1, 1000);
    private static final int CHAMBER_BUFFER = 15000;
    private static final int CHAMBER_ENERGY = 150;
    private static final int INFUSER_ENERGY = 20000;

    public static final SlimefunItemStack EMPTY_DATA_CARD = new SlimefunItemStack(
            "EMPTY_DATA_CARD",
            Material.CHAINMAIL_CHESTPLATE,
            "&8Empty Data Card",
            "&7Infuse with a mob's items to fill"
    );
    public static final SlimefunItemStack INFUSER = new SlimefunItemStack(
            "DATA_INFUSER",
            Material.LODESTONE,
            "&8Mob Data Infuser",
            "&7Infused empty data cards with mob items",
            "",
            MachineLore.energy(INFUSER_ENERGY) + "per use"
    );
    public static final SlimefunItemStack CHAMBER = new SlimefunItemStack(
            "MOB_SIMULATION_CHAMBER",
            Material.GILDED_BLACKSTONE,
            "&8Mob Simulation Chamber",
            "&7Use mob data cards to activate",
            "",
            MachineLore.energyBuffer(CHAMBER_BUFFER),
            MachineLore.energyPerSecond(CHAMBER_ENERGY)
    );

    public static final SlimefunItemStack COW = MobDataCard.create("Cow", MobDataTier.PASSIVE);
    public static final SlimefunItemStack MOOSHROOM = MobDataCard.create("Mooshroom", MobDataTier.PASSIVE);
    public static final SlimefunItemStack SNIFFER = MobDataCard.create("Sniffer", MobDataTier.PASSIVE); //New Sniffer.
    public static final SlimefunItemStack TURTLE = MobDataCard.create("Turtle", MobDataTier.PASSIVE);  //New Turtle
    public static final SlimefunItemStack GLOW_SQUID = MobDataCard.create("Glow Squid", MobDataTier.PASSIVE); //New Glow squid
    public static final SlimefunItemStack RABBIT = MobDataCard.create("Rabbit", MobDataTier.PASSIVE); //New Rabbit
    public static final SlimefunItemStack SHEEP = MobDataCard.create("Sheep", MobDataTier.PASSIVE);
    public static final SlimefunItemStack CHICKEN = MobDataCard.create("Chicken", MobDataTier.PASSIVE);
    
    public static final SlimefunItemStack VILLAGER = MobDataCard.create("Villager", MobDataTier.NEUTRAL);
    public static final SlimefunItemStack FROG = MobDataCard.create("Frog", MobDataTier.NEUTRAL); //New Frog
    public static final SlimefunItemStack BEE = MobDataCard.create("Bee", MobDataTier.NEUTRAL);
    public static final SlimefunItemStack SLIME = MobDataCard.create("Slime", MobDataTier.NEUTRAL);
    public static final SlimefunItemStack MAGMA_CUBE = MobDataCard.create("Magma Cube", MobDataTier.NEUTRAL);

    public static final SlimefunItemStack WITCH = MobDataCard.create("Witch", MobDataTier.ADVANCED);
    public static final SlimefunItemStack SNOW_GOLEM = MobDataCard.create("Snow Golem", MobDataTier.ADVANCED); //New Snowgolem
    public static final SlimefunItemStack ZOMBIE = MobDataCard.create("Zombie", MobDataTier.HOSTILE);
    public static final SlimefunItemStack SPIDER = MobDataCard.create("Spider", MobDataTier.HOSTILE);
    public static final SlimefunItemStack SKELETON = MobDataCard.create("Skeleton", MobDataTier.HOSTILE);
    public static final SlimefunItemStack CREEPER = MobDataCard.create("Creeper", MobDataTier.HOSTILE);
    public static final SlimefunItemStack SHULKER = MobDataCard.create("Shulker", MobDataTier.HOSTILE);
    public static final SlimefunItemStack EVOKER = MobDataCard.create("Evoker", MobDataTier.HOSTILE);

    public static final SlimefunItemStack WITHER_SKELETON = MobDataCard.create("Wither Skeleton", MobDataTier.ADVANCED);
    public static final SlimefunItemStack ENDERMEN = MobDataCard.create("Endermen", MobDataTier.ADVANCED);
    public static final SlimefunItemStack GUARDIAN = MobDataCard.create("Guardian", MobDataTier.HOSTILE);
    public static final SlimefunItemStack IRON_GOLEM = MobDataCard.create("Iron Golem", MobDataTier.ADVANCED);
    public static final SlimefunItemStack BLAZE = MobDataCard.create("Blaze", MobDataTier.ADVANCED);

    public static final SlimefunItemStack WITHER = MobDataCard.create("Wither", MobDataTier.MINI_BOSS);
    public static final SlimefunItemStack WARDEN = MobDataCard.create("Warden", MobDataTier.BOSS); //New Warden
    public static final SlimefunItemStack ENDER_DRAGON = MobDataCard.create("Ender Dragon", MobDataTier.BOSS);

    public static void setup(InfinityExpansion plugin) {

        new MobSimulationChamber(Groups.MOB_SIMULATION, CHAMBER, RecipeType.ENHANCED_CRAFTING_TABLE, new ItemStack[] {
                Materials.MAGSTEEL_PLATE, Materials.MACHINE_PLATE, Materials.MAGSTEEL_PLATE,
                Materials.MACHINE_CIRCUIT, SlimefunItems.PROGRAMMABLE_ANDROID_BUTCHER, Materials.MACHINE_CIRCUIT,
                Materials.MAGSTEEL_PLATE, Materials.MACHINE_PLATE, Materials.MAGSTEEL_PLATE,
        }, CHAMBER_ENERGY, CHAMBER_INTERVAL).register(plugin);

        new MobDataInfuser(Groups.MOB_SIMULATION, INFUSER, RecipeType.ENHANCED_CRAFTING_TABLE, new ItemStack[] {
                Materials.MACHINE_CIRCUIT, SlimefunItems.REINFORCED_ALLOY_INGOT, Materials.MACHINE_CIRCUIT,
                SlimefunItems.REINFORCED_ALLOY_INGOT, Materials.MACHINE_CORE, SlimefunItems.REINFORCED_ALLOY_INGOT,
                Materials.MACHINE_CIRCUIT, SlimefunItems.REINFORCED_ALLOY_INGOT, Materials.MACHINE_CIRCUIT
        }, INFUSER_ENERGY).register(plugin);

        new SlimefunItem(Groups.MOB_SIMULATION, EMPTY_DATA_CARD, RecipeType.ENHANCED_CRAFTING_TABLE, new ItemStack[] {
                SlimefunItems.MAGNESIUM_INGOT, Materials.MACHINE_CIRCUIT, SlimefunItems.MAGNESIUM_INGOT,
                SlimefunItems.SYNTHETIC_SAPPHIRE, SlimefunItems.SYNTHETIC_DIAMOND, SlimefunItems.SYNTHETIC_EMERALD,
                SlimefunItems.MAGNESIUM_INGOT, Materials.MACHINE_CIRCUIT, SlimefunItems.MAGNESIUM_INGOT
        }).register(plugin);

        if (InfinityExpansion.environment() == Environment.TESTING) {
            // There is some issues with player skull items in randomized sets when testing
            return;
        }

        new MobDataCard(ZOMBIE, MobDataTier.HOSTILE, new ItemStack[] {
                new ItemStack(Material.IRON_SWORD, 1), new ItemStack(Material.ROTTEN_FLESH, 16), new ItemStack(Material.IRON_SHOVEL, 1),
                new ItemStack(Material.IRON_INGOT, 64), EMPTY_DATA_CARD, new ItemStack(Material.IRON_INGOT, 64),
                new ItemStack(Material.CARROT, 64), new ItemStack(Material.ROTTEN_FLESH, 16), new ItemStack(Material.POTATO, 64)
        }).addDrop(Material.ROTTEN_FLESH, 1).register(plugin);
        new MobDataCard(SLIME, MobDataTier.NEUTRAL, new ItemStack[] {
                new ItemStack(Material.SLIME_BLOCK, 16), new ItemStack(Material.LIME_DYE, 16), new ItemStack(Material.SLIME_BLOCK, 16),
                new ItemStack(Material.LIME_DYE, 16), EMPTY_DATA_CARD, new ItemStack(Material.LIME_DYE, 16),
                new ItemStack(Material.SLIME_BLOCK, 16), new ItemStack(Material.LIME_DYE, 16), new ItemStack(Material.SLIME_BLOCK, 16)
        }).addDrop(Material.SLIME_BALL, 1).register(plugin);
        new MobDataCard(MAGMA_CUBE, MobDataTier.NEUTRAL, new ItemStack[] {
                new ItemStack(Material.MAGMA_BLOCK, 64), new ItemStack(Material.MAGMA_CREAM, 16), new ItemStack(Material.MAGMA_BLOCK, 64),
                new ItemStack(Material.SLIME_BLOCK, 16), EMPTY_DATA_CARD, new ItemStack(Material.SLIME_BLOCK, 16),
                new ItemStack(Material.MAGMA_BLOCK, 64), new ItemStack(Material.MAGMA_CREAM, 16), new ItemStack(Material.MAGMA_BLOCK, 64)
        }).addDrop(Material.MAGMA_CREAM, 1).register(plugin);
        new MobDataCard(COW, MobDataTier.PASSIVE, new ItemStack[] {
                new ItemStack(Material.LEATHER, 64), new ItemStack(Material.BEEF, 64), new ItemStack(Material.LEATHER, 64),
                new ItemStack(Material.COOKED_BEEF, 64), EMPTY_DATA_CARD, new ItemStack(Material.COOKED_BEEF, 64),
                new ItemStack(Material.LEATHER, 64), new ItemStack(Material.BEEF, 64), new ItemStack(Material.LEATHER, 64)
        }).addDrop(Material.LEATHER, 1).addDrop(Material.BEEF, 1).register(plugin);
        new MobDataCard(SHEEP, MobDataTier.PASSIVE, new ItemStack[] {
                new ItemStack(Material.WHITE_WOOL, 64), new ItemStack(Material.MUTTON, 64), new ItemStack(Material.WHITE_WOOL, 64),
                new ItemStack(Material.COOKED_MUTTON, 64), EMPTY_DATA_CARD, new ItemStack(Material.COOKED_MUTTON, 64),
                new ItemStack(Material.WHITE_WOOL, 64), new ItemStack(Material.MUTTON, 64), new ItemStack(Material.WHITE_WOOL, 64)
        }).addDrop(Material.WHITE_WOOL, 1).addDrop(Material.MUTTON, 1).addDrop(Material.PINK_WOOL, 10000).register(plugin);
        
        //Edited to add Cobweb. 1/19
        new MobDataCard(SPIDER, MobDataTier.HOSTILE, new ItemStack[] {
                new ItemStack(Material.COBWEB, 8), new ItemStack(Material.STRING, 64), new ItemStack(Material.COBWEB, 8),
                new ItemStack(Material.SPIDER_EYE, 32), EMPTY_DATA_CARD, new ItemStack(Material.SPIDER_EYE, 32),
                new ItemStack(Material.COBWEB, 8), new ItemStack(Material.STRING, 64), new ItemStack(Material.COBWEB, 8)
        }).addDrop(Material.STRING, 1).addDrop(Material.SPIDER_EYE, 2).addDrop(Material.COBWEB, 8).register(plugin);
        new MobDataCard(SKELETON, MobDataTier.HOSTILE, new ItemStack[] {
                new ItemStack(Material.LEATHER_HELMET, 1), new ItemStack(Material.BONE, 64), new ItemStack(Material.LEATHER_HELMET, 1),
                new ItemStack(Material.ARROW, 64), EMPTY_DATA_CARD, new ItemStack(Material.ARROW, 64),
                new ItemStack(Material.BOW, 1), new ItemStack(Material.BONE, 64), new ItemStack(Material.BOW, 1)
        }).addDrop(Material.BONE, 1).addDrop(Material.ARROW, 3).register(plugin);
        new MobDataCard(WITHER_SKELETON, MobDataTier.ADVANCED, new ItemStack[] {
                new ItemStack(Material.WITHER_SKELETON_SKULL, 8), new ItemStack(Material.BONE, 64), new ItemStack(Material.WITHER_SKELETON_SKULL, 8),
                new ItemStack(Material.COAL_BLOCK, 64), EMPTY_DATA_CARD, new ItemStack(Material.COAL_BLOCK, 64),
                new ItemStack(Material.STONE_SWORD, 1), new ItemStack(Material.BONE, 64), new ItemStack(Material.STONE_SWORD, 1)
        }).addDrop(Material.COAL, 2, 1).addDrop(Material.BONE, 3).addDrop(Material.WITHER_SKELETON_SKULL, 15).register(plugin);
        new MobDataCard(ENDERMEN, MobDataTier.ADVANCED, new ItemStack[] {
                new ItemStack(Material.ENDER_EYE, 16), new ItemStack(Material.OBSIDIAN, 64), new ItemStack(Material.ENDER_EYE, 16),
                new ItemStack(Material.ENDER_PEARL, 16), EMPTY_DATA_CARD, new ItemStack(Material.ENDER_PEARL, 16),
                new ItemStack(Material.ENDER_EYE, 16), new ItemStack(Material.OBSIDIAN, 64), new ItemStack(Material.ENDER_EYE, 16)
        }).addDrop(Material.ENDER_PEARL, 1).register(plugin);
        new MobDataCard(CREEPER, MobDataTier.HOSTILE, new ItemStack[] {
                new ItemStack(Material.TNT, 16), new ItemStack(Material.GREEN_DYE, 64), new ItemStack(Material.TNT, 16),
                new ItemStack(Material.GUNPOWDER, 16), EMPTY_DATA_CARD, new ItemStack(Material.GUNPOWDER, 16),
                new ItemStack(Material.TNT, 16), new ItemStack(Material.GREEN_DYE, 64), new ItemStack(Material.TNT, 16)
        }).addDrop(Material.GUNPOWDER, 1).register(plugin);
        new MobDataCard(GUARDIAN, MobDataTier.HOSTILE, new ItemStack[] {
                new ItemStack(Material.COD, 16), new ItemStack(Material.PRISMARINE_SHARD, 64), new ItemStack(Material.PRISMARINE_CRYSTALS, 64),
                new ItemStack(Material.SPONGE, 4), EMPTY_DATA_CARD, new ItemStack(Material.PUFFERFISH, 4),
                new ItemStack(Material.PRISMARINE_CRYSTALS, 64), new ItemStack(Material.PRISMARINE_SHARD, 64), new ItemStack(Material.COOKED_COD, 16)
        }).addDrop(Material.PRISMARINE_SHARD, 1).addDrop(Material.PRISMARINE_CRYSTALS, 2)
                .addDrop(Material.COD, 3).addDrop(Material.SPONGE, 40).register(plugin);
        
        //Added Eggs to Drop. 1.19
        new MobDataCard(CHICKEN, MobDataTier.PASSIVE, new ItemStack[] {
                new ItemStack(Material.CHICKEN, 64), new ItemStack(Material.FEATHER, 64), new ItemStack(Material.COOKED_CHICKEN, 64),
                new ItemStack(Material.EGG, 16), EMPTY_DATA_CARD, new ItemStack(Material.EGG, 16),
                new ItemStack(Material.COOKED_CHICKEN, 64), new ItemStack(Material.FEATHER, 64), new ItemStack(Material.CHICKEN, 64)
        }).addDrop(Material.CHICKEN, 1).addDrop(Material.FEATHER, 2).addDrop(Material.EGG, 2).register(plugin);
        new MobDataCard(IRON_GOLEM, MobDataTier.ADVANCED, new ItemStack[] {
                new ItemStack(Material.IRON_BLOCK, 64), new ItemStack(Material.PUMPKIN, 16), new ItemStack(Material.IRON_BLOCK, 64),
                new ItemStack(Material.POPPY, 16), EMPTY_DATA_CARD, new ItemStack(Material.POPPY, 16),
                new ItemStack(Material.IRON_BLOCK, 64), new ItemStack(Material.PUMPKIN, 16), new ItemStack(Material.IRON_BLOCK, 64)
        }).addDrop(Material.IRON_INGOT, 2, 1).addDrop(Material.POPPY, 3).addDrop(SlimefunItems.BASIC_CIRCUIT_BOARD, 3).register(plugin);
        new MobDataCard(BLAZE, MobDataTier.ADVANCED, new ItemStack[] {
                new ItemStack(Material.MAGMA_BLOCK, 64), new ItemStack(Material.BLAZE_ROD, 64), new ItemStack(Material.MAGMA_BLOCK, 64),
                new ItemStack(Material.BLAZE_ROD, 64), EMPTY_DATA_CARD, new ItemStack(Material.BLAZE_ROD, 64),
                new ItemStack(Material.MAGMA_BLOCK, 64), new ItemStack(Material.BLAZE_ROD, 64), new ItemStack(Material.MAGMA_BLOCK, 64)
        }).addDrop(Material.BLAZE_ROD, 1).register(plugin);
        
        //Edited to add Wither Rose 1/19
        new MobDataCard(WITHER, MobDataTier.MINI_BOSS, new ItemStack[] {
                new ItemStack(Material.WITHER_SKELETON_SKULL, 64), new ItemStack(Material.WITHER_SKELETON_SKULL, 64), new ItemStack(Material.WITHER_SKELETON_SKULL, 64),
                new SlimefunItemStack(SlimefunItems.WITHER_PROOF_OBSIDIAN, 64), EMPTY_DATA_CARD, new SlimefunItemStack(SlimefunItems.WITHER_PROOF_OBSIDIAN, 64),
                new SlimefunItemStack(Materials.VOID_INGOT, 4), new SlimefunItemStack(SlimefunItems.WITHER_ASSEMBLER, 4), new SlimefunItemStack(Materials.VOID_INGOT, 4)
        }).addDrop(Material.NETHER_STAR, 1).addDrop(SlimefunItems.COMPRESSED_CARBON, 8, 2).addDrop(Material.WITHER_ROSE, 8).register(plugin);
        
        //Edited to add Dragon's Breath 1/19
        new MobDataCard(ENDER_DRAGON, MobDataTier.BOSS, new ItemStack[] {
                new ItemStack(Material.END_CRYSTAL, 64), new SlimefunItemStack(Materials.VOID_INGOT, 32), new ItemStack(Material.CHORUS_FLOWER, 64),
                SlimefunItems.INFUSED_ELYTRA, EMPTY_DATA_CARD, new ItemStack(Material.DRAGON_HEAD, 1),
                new SlimefunItemStack(SlimefunItems.ENDER_LUMP_3, 64), new SlimefunItemStack(Materials.VOID_INGOT, 32), new ItemStack(Material.DRAGON_BREATH, 64)
        }).addDrop(Materials.VOID_DUST, 1).addDrop(Materials.ENDER_ESSENCE, 4).addDrop(Material.DRAGON_EGG, 1_000_000).addDrop(Material.DRAGON_BREATH, 16).register(plugin);
        
        //Edited to add Honey Bottle 1/19
        new MobDataCard(BEE, MobDataTier.NEUTRAL, new ItemStack[] {
                new ItemStack(Material.HONEYCOMB_BLOCK, 16), new ItemStack(Material.HONEY_BLOCK, 16), new ItemStack(Material.HONEYCOMB_BLOCK, 16),
                new ItemStack(Material.HONEY_BLOCK, 16), EMPTY_DATA_CARD, new ItemStack(Material.HONEY_BLOCK, 16),
                new ItemStack(Material.HONEYCOMB_BLOCK, 16), new ItemStack(Material.HONEY_BLOCK, 16), new ItemStack(Material.HONEYCOMB_BLOCK, 16)
        }).addDrop(Material.HONEYCOMB, 1).addDrop(Material.HONEY_BOTTLE, 2).register(plugin);
        new MobDataCard(VILLAGER, MobDataTier.NEUTRAL, new ItemStack[] {
                new ItemStack(Material.EMERALD, 64), new ItemStack(Material.POTATO, 64), new ItemStack(Material.EMERALD, 64),
                new ItemStack(Material.CARROT, 64), EMPTY_DATA_CARD, new ItemStack(Material.WHEAT, 64),
                new ItemStack(Material.EMERALD, 64), new ItemStack(Material.PUMPKIN, 64), new ItemStack(Material.EMERALD, 64)
        }).addDrop(Material.EMERALD, 1).register(plugin);
        new MobDataCard(WITCH, MobDataTier.ADVANCED, new ItemStack[] {
                new ItemStack(Material.REDSTONE_BLOCK, 64), new ItemStack(Material.GLASS, 64), new ItemStack(Material.SUGAR, 64),
                new ItemStack(Material.GLOWSTONE, 64), EMPTY_DATA_CARD, new ItemStack(Material.GLOWSTONE, 64),
                new ItemStack(Material.SUGAR, 64), new ItemStack(Material.GLASS, 64), new ItemStack(Material.REDSTONE_BLOCK, 64)
        }).addDrop(Material.SUGAR, 1).addDrop(Material.REDSTONE, 1)
                .addDrop(Material.GLASS_BOTTLE, 1).addDrop(Material.GLOWSTONE_DUST, 1).register(plugin);
        
        //Edited to Add 1/19
        new MobDataCard(SNIFFER, MobDataTier.PASSIVE, new ItemStack[] {
                new ItemStack(Material.TORCHFLOWER, 8), new ItemStack(Material.TORCHFLOWER_SEEDS, 8), new ItemStack(Material.TORCHFLOWER, 8),
                new ItemStack(Material.SNIFFER_EGG, 1), EMPTY_DATA_CARD, new ItemStack(Material.SNIFFER_EGG, 1),
                new ItemStack(Material.PITCHER_PLANT, 8), new ItemStack(Material.PITCHER_POD, 8), new ItemStack(Material.PITCHER_PLANT, 8)
        }).addDrop(Material.TORCHFLOWER, 1).addDrop(Material.TORCHFLOWER_SEEDS, 6).addDrop(Material.PITCHER_PLANT, 1).addDrop(Material.PITCHER_POD, 6).addDrop(Material.SNIFFER_EGG, 32).register(plugin);
        
        //Edited to Add 1/19
        new MobDataCard(FROG, MobDataTier.NEUTRAL, new ItemStack[] {
                new ItemStack(Material.SLIME_BALL, 64), new ItemStack(Material.LILY_PAD, 16), new ItemStack(Material.MAGMA_CREAM, 64),
                new ItemStack(Material.MUD, 16), EMPTY_DATA_CARD, new ItemStack(Material.VINE, 16),
                new ItemStack(Material.MAGMA_CREAM, 64), new ItemStack(Material.BLUE_ICE, 16), new ItemStack(Material.SLIME_BALL, 64)
        }).addDrop(Material.PEARLESCENT_FROGLIGHT, 2).addDrop(Material.VERDANT_FROGLIGHT, 2).addDrop(Material.OCHRE_FROGLIGHT, 2).addDrop(Material.LILY_PAD, 4).register(plugin);
        
        //Edited to Add 1/19
        new MobDataCard(TURTLE, MobDataTier.PASSIVE, new ItemStack[] {
                new ItemStack(Material.SEAGRASS, 64), new ItemStack(Material.KELP, 64), new ItemStack(Material.SEAGRASS, 64),
                new ItemStack(Material.TURTLE_EGG, 16), EMPTY_DATA_CARD, new ItemStack(Material.TURTLE_EGG, 16),
                new ItemStack(Material.SEAGRASS, 64), new ItemStack(Material.KELP, 64), new ItemStack(Material.SEAGRASS, 64)
        }).addDrop(Material.SEAGRASS, 2).addDrop(Material.SCUTE, 6).addDrop(Material.BOWL, 153).addDrop(Material.TURTLE_EGG, 32).register(plugin);
        
        //Edited to Add 1/19
        new MobDataCard(GLOW_SQUID, MobDataTier.PASSIVE, new ItemStack[] {
                new ItemStack(Material.GLOW_INK_SAC, 8), new ItemStack(Material.INK_SAC, 64), new ItemStack(Material.GLOW_INK_SAC, 8),
                new ItemStack(Material.GLOW_LICHEN, 8), EMPTY_DATA_CARD, new ItemStack(Material.GLOW_LICHEN, 8),
                new ItemStack(Material.GLOW_INK_SAC, 8), new ItemStack(Material.INK_SAC, 64), new ItemStack(Material.GLOW_INK_SAC, 8)
        }).addDrop(Material.GLOW_INK_SAC, 1).addDrop(Material.GLOW_LICHEN, 3).addDrop(Material.INK_SAC, 9).register(plugin);
        
        //Edited to Add 1/19
        new MobDataCard(RABBIT, MobDataTier.PASSIVE, new ItemStack[] {
                new ItemStack(Material.COOKED_RABBIT, 32), new ItemStack(Material.RABBIT_HIDE, 16), new ItemStack(Material.RABBIT, 32),
                new ItemStack(Material.CARROT, 64), EMPTY_DATA_CARD, new ItemStack(Material.CARROT, 64),
                new ItemStack(Material.RABBIT, 32), new ItemStack(Material.RABBIT_HIDE, 16),new ItemStack(Material.COOKED_RABBIT, 32)
        }).addDrop(Material.RABBIT, 2).addDrop(Material.RABBIT_HIDE, 3).addDrop(Material.RABBIT_FOOT, 9).register(plugin);
        
        //Edited to Add 1/19 
        //Edited to Fix Recipe 5/25
        new MobDataCard(SNOW_GOLEM, MobDataTier.ADVANCED, new ItemStack[] {
                new ItemStack(Material.SNOW, 16), new ItemStack(Material.CARVED_PUMPKIN, 32), new ItemStack(Material.SNOW, 16),
                new ItemStack(Material.POWDER_SNOW_BUCKET, 1), EMPTY_DATA_CARD, new ItemStack(Material.POWDER_SNOW_BUCKET, 1),
                new ItemStack(Material.SNOW, 16), new ItemStack(Material.SNOW_BLOCK, 64), new ItemStack(Material.SNOW, 16)
        }).addDrop(Material.SNOWBALL, 2).addDrop(Material.SNOW, 3).addDrop(Material.CARVED_PUMPKIN, 256).addDrop(Material.POWDER_SNOW_BUCKET, 32).register(plugin);
        
        //Edited to Add 1/19
        new MobDataCard(WARDEN, MobDataTier.BOSS, new ItemStack[] {
                new ItemStack(Material.SCULK_VEIN, 16), new ItemStack(Material.SCULK_SENSOR, 8),new ItemStack(Material.SCULK, 64),
                new ItemStack(Material.SCULK_CATALYST, 64), EMPTY_DATA_CARD, new ItemStack(Material.SCULK_CATALYST, 64),
                new ItemStack(Material.SCULK, 64), new ItemStack(Material.TOTEM_OF_UNDYING, 1),new ItemStack(Material.SCULK_VEIN, 16)
        }).addDrop(Material.SCULK_VEIN, 1).addDrop(Material.SCULK, 2).addDrop(Material.SCULK_CATALYST, 16).addDrop(Material.SCULK_SENSOR, 64).addDrop(Material.ECHO_SHARD, 64).addDrop(Material.SCULK_SHRIEKER, 256).addDrop(Material.REINFORCED_DEEPSLATE, 256).register(plugin);
        
        //Edited to Add 1/19
        new MobDataCard(MOOSHROOM, MobDataTier.PASSIVE, new ItemStack[] {
                new ItemStack(Material.LEATHER, 64), new ItemStack(Material.RED_MUSHROOM, 64), new ItemStack(Material.LEATHER, 64),
                new ItemStack(Material.BROWN_MUSHROOM_BLOCK, 64), EMPTY_DATA_CARD, new ItemStack(Material.RED_MUSHROOM_BLOCK, 64),
                new ItemStack(Material.LEATHER, 64), new ItemStack(Material.BROWN_MUSHROOM, 64), new ItemStack(Material.LEATHER, 64)
        }).addDrop(Material.RED_MUSHROOM, 1).addDrop(Material.BROWN_MUSHROOM, 1).addDrop(Material.MUSHROOM_STEW, 32).register(plugin);
       
        //Edited to Add 1/19
        new MobDataCard(SHULKER, MobDataTier.HOSTILE, new ItemStack[] {
                new ItemStack(Material.SHULKER_SHELL,8), new ItemStack(Material.PURPUR_PILLAR, 64), new ItemStack(Material.SHULKER_SHELL,8),
                new ItemStack(Material.END_STONE_BRICKS, 64), EMPTY_DATA_CARD, new ItemStack(Material.END_STONE_BRICKS, 64),
                new ItemStack(Material.SHULKER_SHELL,8), new ItemStack(Material.PURPUR_PILLAR, 64), new ItemStack(Material.SHULKER_SHELL,8)
        }).addDrop(Material.SHULKER_SHELL, 8).addDrop(Material.END_STONE, 32).register(plugin);
        
        //Edited to Add 1/19
        new MobDataCard(EVOKER, MobDataTier.HOSTILE, new ItemStack[] {
                new ItemStack(Material.EMERALD, 64), new ItemStack(Material.IRON_AXE, 1), new ItemStack(Material.EMERALD, 64),
                new ItemStack(Material.TOTEM_OF_UNDYING, 1), EMPTY_DATA_CARD, new ItemStack(Material.TOTEM_OF_UNDYING, 1),
                new ItemStack(Material.EMERALD, 64), new ItemStack(Material.IRON_AXE, 1), new ItemStack(Material.EMERALD, 64)
        }).addDrop(Material.TOTEM_OF_UNDYING, 16).addDrop(Material.IRON_INGOT, 16).addDrop(Material.BOOK, 16).register(plugin);
    }

}
